package iisc.ac.in.Booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import iisc.ac.in.Booking.entity.Show;

public interface ShowRepository extends JpaRepository<Show, Integer>{

}
